@echo off
title BlankDelay - Aim Bundle
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Aim-Bundle.html"
