BlankDelay — Aim Bundle

1. Unzip this file
2. Double-click "Open BlankDelay Aim Bundle.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-Aim-Bundle.zip
Product ID: aim-bundle
