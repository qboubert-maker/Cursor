@echo off
title BlankDelay - Blank Premium Utility
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Blank-Premium-Utility.html"
