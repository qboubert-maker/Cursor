BlankDelay — Blank Premium Utility

1. Unzip this file
2. Double-click "Open BlankDelay Blank Premium Utility.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-Blank-Premium-Utility.zip
Product ID: blank-premium-utility
