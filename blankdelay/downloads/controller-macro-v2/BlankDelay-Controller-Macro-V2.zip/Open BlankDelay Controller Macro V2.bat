@echo off
title BlankDelay - Controller Macro V2
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Controller-Macro-V2.html"
