BlankDelay — Controller Macro V2

1. Unzip this file
2. Double-click "Open BlankDelay Controller Macro V2.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-Controller-Macro-V2.zip
Product ID: controller-macro-v2
