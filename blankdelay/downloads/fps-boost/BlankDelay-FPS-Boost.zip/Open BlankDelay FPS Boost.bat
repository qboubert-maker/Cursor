@echo off
title BlankDelay - FPS Boost
cd /d "%~dp0"
start "" "%~dp0BlankDelay-FPS-Boost.html"
