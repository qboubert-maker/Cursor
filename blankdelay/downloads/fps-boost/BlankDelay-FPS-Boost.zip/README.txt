BlankDelay — FPS Boost

1. Unzip this file
2. Double-click "Open BlankDelay FPS Boost.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-FPS-Boost.zip
Product ID: fps-boost
