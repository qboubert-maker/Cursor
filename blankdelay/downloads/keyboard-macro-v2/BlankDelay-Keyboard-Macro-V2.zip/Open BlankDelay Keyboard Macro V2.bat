@echo off
title BlankDelay - Keyboard Macro V2
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Keyboard-Macro-V2.html"
