@echo off
title BlankDelay - Ping Optimizer
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Ping-Optimizer.html"
