BlankDelay — Ping Optimizer

1. Unzip this file
2. Double-click "Open BlankDelay Ping Optimizer.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-Ping-Optimizer.zip
Product ID: ping-optimizer
