@echo off
title BlankDelay - Shotgun Pack
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Shotgun-Pack.html"
