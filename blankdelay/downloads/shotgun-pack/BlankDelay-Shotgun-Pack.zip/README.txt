BlankDelay — Shotgun Pack

1. Unzip this file
2. Double-click "Open BlankDelay Shotgun Pack.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-Shotgun-Pack.zip
Product ID: shotgun-pack
