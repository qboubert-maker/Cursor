@echo off
title BlankDelay - Zero Delay Plus
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Zero-Delay-Plus.html"
