BlankDelay — Zero Delay Plus

1. Unzip this file
2. Double-click "Open BlankDelay Zero Delay Plus.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-Zero-Delay-Plus.zip
Product ID: zero-delay-plus
