@echo off
title BlankDelay - Zero Delay
cd /d "%~dp0"
start "" "%~dp0BlankDelay-Zero-Delay.html"
