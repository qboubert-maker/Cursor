BlankDelay — Zero Delay

1. Unzip this file
2. Double-click "Open BlankDelay Zero Delay.bat"
   (or open the .html file)
3. Paste your license key and click Activate

Zip name: BlankDelay-Zero-Delay.zip
Product ID: zero-delay
